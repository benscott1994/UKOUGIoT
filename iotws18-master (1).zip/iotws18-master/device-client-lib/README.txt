This is IoTCS device library in NodeJS, for IoTCS version 16.4.1.x

Please copy this nodejs code into ./node_modules directory.
